chapter3
==================

Code for the third chapter of the book, dedicated to the cloud-based security camera

- pir_test: a simple sketch to test the motion sensor connected to the Arduino Yun
- triggered_camera: the Arduino sketch to test the camera triggered by the motion sensor, and store pictures locally on the SD card
- dropbox_log: the main sketch of the project, that sends recorded pictures to Dropbox
