chapter2
==================

Code for the second chapter of the book, dedicated to the cloud-connected energy meter:

- sensors_test: a simple sketch to test the different sensors connected to the Arduino Yun
- energy_log: the main sketch of the project, that sends data to a Google Docs spreadsheet
- web_interface: all the files required for the web interface to remotely control the relay