chapter3
==================

Code for the fourth chapter of the book, dedicated to build a robot around the Arduino Yun

- robot_test: a simple sketch to test the DC motors of the robot and the ultrasonic distance sensor
- remote_control: include the interface to control the robot remotely, and the sketches for the Uno & Yun board