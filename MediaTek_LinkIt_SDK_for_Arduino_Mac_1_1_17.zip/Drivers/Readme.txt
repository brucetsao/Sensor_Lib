Readme

This document explains how to install and run the MediaTek USB serial port driver on your MacOS 10.10.

Install MediaTek USB serial port driver
	
	1. Open install package (Ex. "BMCDCACM_Driver_Vxxx.xx.x.mpkg") and follow the instruction to install it.
	2. Wait until the driver is installed successfully and reboot your MacOS.
	
	Now, the MediaTek USB serial port driver installation is completed.


Uninstall driver
	1 Open the Terminal
	2 Run command as follow:
		"sudo rm -rf /System/Library/Extensions/BMUSBCDC.kext"
		"sudo touch /System/Library/Extensions/"
		"sudo sync"
	3 Reboot MacOS
	
