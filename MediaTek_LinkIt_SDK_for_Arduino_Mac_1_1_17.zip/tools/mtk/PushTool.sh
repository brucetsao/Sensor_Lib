#!/bin/sh

$(dirname $0)/PushTool -d arduino -b $1 -p $2
