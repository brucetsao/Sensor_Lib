#!/bin/sh

$(dirname $0)/PackTag -i $1