require('coffee-script');
require('coffee-script/register');
var server = require('./server');
server.startServer();
