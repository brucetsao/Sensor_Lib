#!/bin/sh
vagrant ssh -c "cd /vagrant && npm run dev"

