#!/bin/sh
vagrant ssh -c "cd /vagrant && BRUNCH_ENV=vagrant npm run brunch watch"

