#!/bin/sh
vagrant ssh -c "cd /vagrant/scripts/vagrant && bash fillMongo.sh"

