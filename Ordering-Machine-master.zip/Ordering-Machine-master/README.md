# Ordering-Machine

This is a small project for demo purpose only.
For further detail, please refer to http://ezmk.org
