/*
*========================================================================================================
*
* File                : main.c
* Hardware Environment:	OpenPIC16F877A && 8LED &&  nrf24l01 && 5v voltage && 4M/8M crystal oscillator
 && 
* Build Environment   : MPLAB IDE
* Version             : V8.76
* By                  : Zhou Jie
*
*                                  (c) Copyright 2011-2016, WaveShare
*                                       http://www.waveShare.net
*                                          All Rights Reserved
*
*========================================================================================================
*/

#include <pic.h>

#include "24L01.h"

#define T_O_R	1			
//#define T_O_R	0			

#define u16			unsigned int

 void uart_int()
{
     SPBRG=0XC;                 
  TXSTA=0X24;                 
  RCSTA=0X90;                
  TXIE=0X0;                   
  GIE=0X1;                    
  PEIE=0X1;                 
}
void delay_ms(u16 ms)
{
	while(--ms);
}
void main(void)
{
spi_init();
uart_int();
	nRF24L01_Initial();

PORTB=0X02;
TRISD1=1;

	while(1)
	{

		if(T_O_R)
		{while(RD1==1);
			//TX_Mode();
			delay_ms(300);				
			NRF24L01_Send();
		}
		else
		{
				NRF24L01_Receive();
		}
	}
}

