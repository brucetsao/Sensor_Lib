
#ifndef _USART_H_
#define _USART_H_


void putUsart0(unsigned char c);

void usartInit(void);


#endif /*_WS_USART_H_*/
